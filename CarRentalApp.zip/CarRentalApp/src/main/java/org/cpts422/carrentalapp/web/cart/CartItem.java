// Created by : Yevin
// Created on : Sep 28

// Last Updated by : Yevin
// Last Updated on : Sep 28

package org.cpts422.carrentalapp.web.cart;

public class CartItem
{
    private CartItemType type;
    private Long vehicleId;
    private String vehicleLabel;
    private int days;
    private double amount;
    private Long rentalId;

    // Getters and Setters
    public CartItemType getType() { return type; }
    public void setType(CartItemType type) { this.type = type; }
    public Long getVehicleId() { return vehicleId; }
    public void setVehicleId(Long vehicleId) { this.vehicleId = vehicleId; }
    public String getVehicleLabel() { return vehicleLabel; }
    public void setVehicleLabel(String vehicleLabel) { this.vehicleLabel = vehicleLabel; }
    public int getDays() { return days; }
    public void setDays(int days) { this.days = days; }
    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
    public Long getRentalId() { return rentalId; }
    public void setRentalId(Long rentalId) { this.rentalId = rentalId; }
}
