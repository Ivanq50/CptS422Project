package org.cpts422.carrentalapp.web;

import jakarta.servlet.http.HttpSession;
import org.cpts422.carrentalapp.model.*;
import org.cpts422.carrentalapp.repo.RentalRepository;
import org.cpts422.carrentalapp.service.PricingService;
import org.cpts422.carrentalapp.web.cart.Cart;
import org.cpts422.carrentalapp.web.cart.CartItem;
import org.cpts422.carrentalapp.web.cart.CartItemType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.List;

@Controller
public class RentalController {

    private final RentalRepository rentals;
    private final PricingService pricing;
    private final Cart cart;

    public RentalController(RentalRepository rentals, PricingService pricing, Cart cart) {
        this.rentals = rentals;
        this.pricing = pricing;
        this.cart = cart;
    }

    @GetMapping("/my-rentals")
    public String myRentals(HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        List<Rental> list = rentals.findByUserIdAndReturnedAtIsNull(userId);
        model.addAttribute("rentals", list);
        return "my_rentals";
    }

    @PostMapping("/rentals/{id}/start-return")
    public String startReturn(@PathVariable Long id, RedirectAttributes ra) {
        Rental r = rentals.findById(id).orElseThrow();

        double penalty = pricing.penaltyTotal(r);

        if (penalty <= 0.0) {
            r.setReturnedAt(LocalDate.now());
            rentals.save(r);

            Vehicle v = r.getVehicle();
            v.setAvailable(true);
            ra.addFlashAttribute("msg", "Returned on time — no penalty.");
            return "redirect:/my-rentals";
        }

        CartItem it = new CartItem();
        it.setType(CartItemType.PENALTY);
        it.setRentalId(r.getId());
        it.setVehicleLabel(r.getVehicle().getMake() + " " + r.getVehicle().getModel() + " (penalty)");
        it.setAmount(penalty);
        cart.addItem(it);

        ra.addFlashAttribute("msg", "Penalty added to cart. Please pay to complete return.");
        return "redirect:/cart";
    }
}