// Created by : Yevin
// Created on : Sep 28

// Last Updated by : Yevin
// Last Updated on : Sep 28

package org.cpts422.carrentalapp.service;

import org.cpts422.carrentalapp.model.*;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

@Service
public class PricingService {

    public double rentalTotal(AppUser user, Vehicle vehicle, int days)
    {
        double base = vehicle.getDailyRate() * days;

        if (user.getMembershipType() == MembershipType.PREMIUM)
        {
            base *= 0.90; // 10% off
        }

        if (user.getAge() < 25)
        {
            base *= 1.02; // +2%
        }
        return round2(base);
    }

    public double penaltyTotal(Rental rental)
    {
        LocalDate due = rental.getExpectedReturnAt();
        LocalDate today = LocalDate.now();

        long overdueDays = ChronoUnit.DAYS.between(due, today);
        if (rental.getUser().getMembershipType() == MembershipType.PREMIUM)
        {
            overdueDays -= 1; // 1-day grace
        }
        if (overdueDays <= 0) return 0.0;

        double penalty = overdueDays * (rental.getVehicle().getDailyRate() * 0.50);
        return round2(penalty);
    }

    public LocalDate today() { return LocalDate.now(); }

    private double round2(double x) { return Math.round(x * 100.0) / 100.0; }
}